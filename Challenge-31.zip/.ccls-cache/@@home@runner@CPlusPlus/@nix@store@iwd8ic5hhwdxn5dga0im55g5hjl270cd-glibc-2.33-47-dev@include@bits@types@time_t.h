#ifndef __time_t_defined
#define __time_t_defined 1

#include <bits/types.h>

/* Returned by `time'.  */
typedef __time_t time_t;

#endif
